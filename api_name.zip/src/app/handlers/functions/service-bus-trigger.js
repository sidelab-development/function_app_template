/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 815:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const sidelab_http_exceptions_1 = __webpack_require__(197);
const defaultHeader = {
    'Access-Control-Allow-Headers': ['Content-Type', 'contenttype', 'authorization'],
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,PATCH,POST,DELETE',
};
function handleResponse(body, status = sidelab_http_exceptions_1.HTTP_STATUS_CODE.GET) {
    return {
        headers: defaultHeader,
        status,
        body,
    };
}
exports["default"] = handleResponse;


/***/ }),

/***/ 197:
/***/ ((module) => {

module.exports = require("sidelab-http-exceptions");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("tslib");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(752);
const sidelab_http_exceptions_1 = __webpack_require__(197);
const handle_response_1 = tslib_1.__importDefault(__webpack_require__(815));
const handler = async (context, serviceBusMessage) => {
    const { id } = serviceBusMessage;
    try {
        const response = { id };
        context.res = (0, handle_response_1.default)(response, sidelab_http_exceptions_1.HTTP_STATUS_CODE.GET);
    }
    catch (error) {
        context.res = (0, sidelab_http_exceptions_1.handleError)(error, context);
    }
};
exports["default"] = handler;

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvYXBwL2hhbmRsZXJzL2Z1bmN0aW9ucy9zZXJ2aWNlLWJ1cy10cmlnZ2VyLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBO0FBR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBTkE7Ozs7Ozs7O0FDZkE7Ozs7Ozs7QUNBQTs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7QUN0QkE7QUFFQTtBQUdBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBR0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGlfbmFtZS8uL3NyYy9hcHAvaGFuZGxlcnMvdXRpbHMvaGFuZGxlLXJlc3BvbnNlLnRzIiwid2VicGFjazovL2FwaV9uYW1lL2V4dGVybmFsIGNvbW1vbmpzIFwic2lkZWxhYi1odHRwLWV4Y2VwdGlvbnNcIiIsIndlYnBhY2s6Ly9hcGlfbmFtZS9leHRlcm5hbCBjb21tb25qcyBcInRzbGliXCIiLCJ3ZWJwYWNrOi8vYXBpX25hbWUvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vYXBpX25hbWUvLi9zcmMvYXBwL2hhbmRsZXJzL2Z1bmN0aW9ucy9zZXJ2aWNlLWJ1cy10cmlnZ2VyL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEhUVFBfU1RBVFVTX0NPREUgfSBmcm9tICdzaWRlbGFiLWh0dHAtZXhjZXB0aW9ucyc7XG5pbXBvcnQgeyBJR2VuZXJpY09iamVjdCB9IGZyb20gJy4uLy4uL2ludGVyZmFjZXMvZ2VuZXJpYy1vYmplY3QnO1xuXG5jb25zdCBkZWZhdWx0SGVhZGVyID0ge1xuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctSGVhZGVycyc6IFsnQ29udGVudC1UeXBlJywgJ2NvbnRlbnR0eXBlJywgJ2F1dGhvcml6YXRpb24nXSxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU9yaWdpbic6ICcqJyxcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LU1ldGhvZHMnOiAnT1BUSU9OUyxQT1NULEdFVCxQVVQsUEFUQ0gsUE9TVCxERUxFVEUnLFxufTtcblxuaW50ZXJmYWNlIElIYW5kbGVkUmVzcG9uc2Uge1xuICBoZWFkZXJzOiBJR2VuZXJpY09iamVjdDtcbiAgc3RhdHVzOiBudW1iZXI7XG4gIGJvZHk6IGFueTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBoYW5kbGVSZXNwb25zZShib2R5OiBhbnksIHN0YXR1cyA9IEhUVFBfU1RBVFVTX0NPREUuR0VUKTogSUhhbmRsZWRSZXNwb25zZSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbiAgcmV0dXJuIHtcbiAgICBoZWFkZXJzOiBkZWZhdWx0SGVhZGVyLFxuICAgIHN0YXR1cyxcbiAgICBib2R5LFxuICB9O1xufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic2lkZWxhYi1odHRwLWV4Y2VwdGlvbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwidHNsaWJcIik7IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsImltcG9ydCB7IEF6dXJlRnVuY3Rpb24sIENvbnRleHQgfSBmcm9tICdAYXp1cmUvZnVuY3Rpb25zJztcbmltcG9ydCB7IGhhbmRsZUVycm9yLCBIVFRQX1NUQVRVU19DT0RFIH0gZnJvbSAnc2lkZWxhYi1odHRwLWV4Y2VwdGlvbnMnO1xuaW1wb3J0IHsgSUdlbmVyaWNPYmplY3QgfSBmcm9tICcuLi8uLi8uLi9pbnRlcmZhY2VzL2dlbmVyaWMtb2JqZWN0JztcbmltcG9ydCBoYW5kbGVSZXNwb25zZSBmcm9tICcuLi8uLi91dGlscy9oYW5kbGUtcmVzcG9uc2UnO1xuXG4vLyB0cy1wcnVuZS1pZ25vcmUtbmV4dFxuY29uc3QgaGFuZGxlcjogQXp1cmVGdW5jdGlvbiA9IGFzeW5jIChjb250ZXh0OiBDb250ZXh0LCBzZXJ2aWNlQnVzTWVzc2FnZTogSUdlbmVyaWNPYmplY3QpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgY29uc3QgeyBpZCB9ID0gc2VydmljZUJ1c01lc3NhZ2U7XG5cbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IHsgaWQgfTtcbiAgICBjb250ZXh0LnJlcyA9IGhhbmRsZVJlc3BvbnNlKHJlc3BvbnNlLCBIVFRQX1NUQVRVU19DT0RFLkdFVCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29udGV4dC5yZXMgPSBoYW5kbGVFcnJvcihlcnJvciwgY29udGV4dCk7XG4gIH1cbn07XG5cbi8vIHRzLXBydW5lLWlnbm9yZS1uZXh0XG5leHBvcnQgZGVmYXVsdCBoYW5kbGVyO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9