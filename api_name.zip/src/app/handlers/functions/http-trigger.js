/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 815:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const sidelab_http_exceptions_1 = __webpack_require__(197);
const defaultHeader = {
    'Access-Control-Allow-Headers': ['Content-Type', 'contenttype', 'authorization'],
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,PATCH,POST,DELETE',
};
function handleResponse(body, status = sidelab_http_exceptions_1.HTTP_STATUS_CODE.GET) {
    return {
        headers: defaultHeader,
        status,
        body,
    };
}
exports["default"] = handleResponse;


/***/ }),

/***/ 197:
/***/ ((module) => {

module.exports = require("sidelab-http-exceptions");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("tslib");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(752);
const sidelab_http_exceptions_1 = __webpack_require__(197);
const handle_response_1 = tslib_1.__importDefault(__webpack_require__(815));
const handler = async (context, req) => {
    const { id } = req.params;
    try {
        const response = { id };
        context.res = (0, handle_response_1.default)(response, sidelab_http_exceptions_1.HTTP_STATUS_CODE.GET);
    }
    catch (error) {
        context.res = (0, sidelab_http_exceptions_1.handleError)(error, context);
    }
};
exports["default"] = handler;

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvYXBwL2hhbmRsZXJzL2Z1bmN0aW9ucy9odHRwLXRyaWdnZXIuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBUUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFOQTs7Ozs7Ozs7QUNmQTs7Ozs7OztBQ0FBOzs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ3RCQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFHQSIsInNvdXJjZXMiOlsid2VicGFjazovL2FwaV9uYW1lLy4vc3JjL2FwcC9oYW5kbGVycy91dGlscy9oYW5kbGUtcmVzcG9uc2UudHMiLCJ3ZWJwYWNrOi8vYXBpX25hbWUvZXh0ZXJuYWwgY29tbW9uanMgXCJzaWRlbGFiLWh0dHAtZXhjZXB0aW9uc1wiIiwid2VicGFjazovL2FwaV9uYW1lL2V4dGVybmFsIGNvbW1vbmpzIFwidHNsaWJcIiIsIndlYnBhY2s6Ly9hcGlfbmFtZS93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9hcGlfbmFtZS8uL3NyYy9hcHAvaGFuZGxlcnMvZnVuY3Rpb25zL2h0dHAtdHJpZ2dlci9pbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBIVFRQX1NUQVRVU19DT0RFIH0gZnJvbSAnc2lkZWxhYi1odHRwLWV4Y2VwdGlvbnMnO1xuaW1wb3J0IHsgSUdlbmVyaWNPYmplY3QgfSBmcm9tICcuLi8uLi9pbnRlcmZhY2VzL2dlbmVyaWMtb2JqZWN0JztcblxuY29uc3QgZGVmYXVsdEhlYWRlciA9IHtcbiAgJ0FjY2Vzcy1Db250cm9sLUFsbG93LUhlYWRlcnMnOiBbJ0NvbnRlbnQtVHlwZScsICdjb250ZW50dHlwZScsICdhdXRob3JpemF0aW9uJ10sXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1PcmlnaW4nOiAnKicsXG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1NZXRob2RzJzogJ09QVElPTlMsUE9TVCxHRVQsUFVULFBBVENILFBPU1QsREVMRVRFJyxcbn07XG5cbmludGVyZmFjZSBJSGFuZGxlZFJlc3BvbnNlIHtcbiAgaGVhZGVyczogSUdlbmVyaWNPYmplY3Q7XG4gIHN0YXR1czogbnVtYmVyO1xuICBib2R5OiBhbnk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaGFuZGxlUmVzcG9uc2UoYm9keTogYW55LCBzdGF0dXMgPSBIVFRQX1NUQVRVU19DT0RFLkdFVCk6IElIYW5kbGVkUmVzcG9uc2UgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4gIHJldHVybiB7XG4gICAgaGVhZGVyczogZGVmYXVsdEhlYWRlcixcbiAgICBzdGF0dXMsXG4gICAgYm9keSxcbiAgfTtcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInNpZGVsYWItaHR0cC1leGNlcHRpb25zXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInRzbGliXCIpOyIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0obW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCJpbXBvcnQgeyBBenVyZUZ1bmN0aW9uLCBDb250ZXh0LCBIdHRwUmVxdWVzdCB9IGZyb20gJ0BhenVyZS9mdW5jdGlvbnMnO1xuaW1wb3J0IHsgaGFuZGxlRXJyb3IsIEhUVFBfU1RBVFVTX0NPREUgfSBmcm9tICdzaWRlbGFiLWh0dHAtZXhjZXB0aW9ucyc7XG5pbXBvcnQgaGFuZGxlUmVzcG9uc2UgZnJvbSAnLi4vLi4vdXRpbHMvaGFuZGxlLXJlc3BvbnNlJztcblxuY29uc3QgaGFuZGxlcjogQXp1cmVGdW5jdGlvbiA9IGFzeW5jIChjb250ZXh0OiBDb250ZXh0LCByZXE6IEh0dHBSZXF1ZXN0KTogUHJvbWlzZTx2b2lkPiA9PiB7XG4gIGNvbnN0IHsgaWQgfSA9IHJlcS5wYXJhbXM7XG4gIHRyeSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSB7IGlkIH07XG4gICAgY29udGV4dC5yZXMgPSBoYW5kbGVSZXNwb25zZShyZXNwb25zZSwgSFRUUF9TVEFUVVNfQ09ERS5HRVQpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnRleHQucmVzID0gaGFuZGxlRXJyb3IoZXJyb3IsIGNvbnRleHQpO1xuICB9XG59O1xuXG4vLyB0cy1wcnVuZS1pZ25vcmUtbmV4dFxuZXhwb3J0IGRlZmF1bHQgaGFuZGxlcjtcbiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==