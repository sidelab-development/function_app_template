/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 815:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
const sidelab_http_exceptions_1 = __webpack_require__(197);
const defaultHeader = {
    'Access-Control-Allow-Headers': ['Content-Type', 'contenttype', 'authorization'],
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,PATCH,POST,DELETE',
};
function handleResponse(body, status = sidelab_http_exceptions_1.HTTP_STATUS_CODE.GET) {
    return {
        headers: defaultHeader,
        status,
        body,
    };
}
exports["default"] = handleResponse;


/***/ }),

/***/ 197:
/***/ ((module) => {

module.exports = require("sidelab-http-exceptions");

/***/ }),

/***/ 752:
/***/ ((module) => {

module.exports = require("tslib");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;

Object.defineProperty(exports, "__esModule", ({ value: true }));
const tslib_1 = __webpack_require__(752);
const sidelab_http_exceptions_1 = __webpack_require__(197);
const handle_response_1 = tslib_1.__importDefault(__webpack_require__(815));
const handler = async (context, eventHubMessages) => {
    const { id } = eventHubMessages;
    try {
        const response = { id };
        context.res = (0, handle_response_1.default)(response, sidelab_http_exceptions_1.HTTP_STATUS_CODE.ACCEPTED);
    }
    catch (error) {
        context.res = (0, sidelab_http_exceptions_1.handleError)(error, context);
    }
};
exports["default"] = handler;

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvYXBwL2hhbmRsZXJzL2Z1bmN0aW9ucy9ldmVudC1odWItdHJpZ2dlci5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFRQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQU5BOzs7Ozs7OztBQ2ZBOzs7Ozs7O0FDQUE7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7O0FDdEJBO0FBRUE7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUdBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBpX25hbWUvLi9zcmMvYXBwL2hhbmRsZXJzL3V0aWxzL2hhbmRsZS1yZXNwb25zZS50cyIsIndlYnBhY2s6Ly9hcGlfbmFtZS9leHRlcm5hbCBjb21tb25qcyBcInNpZGVsYWItaHR0cC1leGNlcHRpb25zXCIiLCJ3ZWJwYWNrOi8vYXBpX25hbWUvZXh0ZXJuYWwgY29tbW9uanMgXCJ0c2xpYlwiIiwid2VicGFjazovL2FwaV9uYW1lL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL2FwaV9uYW1lLy4vc3JjL2FwcC9oYW5kbGVycy9mdW5jdGlvbnMvZXZlbnQtaHViLXRyaWdnZXIvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSFRUUF9TVEFUVVNfQ09ERSB9IGZyb20gJ3NpZGVsYWItaHR0cC1leGNlcHRpb25zJztcbmltcG9ydCB7IElHZW5lcmljT2JqZWN0IH0gZnJvbSAnLi4vLi4vaW50ZXJmYWNlcy9nZW5lcmljLW9iamVjdCc7XG5cbmNvbnN0IGRlZmF1bHRIZWFkZXIgPSB7XG4gICdBY2Nlc3MtQ29udHJvbC1BbGxvdy1IZWFkZXJzJzogWydDb250ZW50LVR5cGUnLCAnY29udGVudHR5cGUnLCAnYXV0aG9yaXphdGlvbiddLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctT3JpZ2luJzogJyonLFxuICAnQWNjZXNzLUNvbnRyb2wtQWxsb3ctTWV0aG9kcyc6ICdPUFRJT05TLFBPU1QsR0VULFBVVCxQQVRDSCxQT1NULERFTEVURScsXG59O1xuXG5pbnRlcmZhY2UgSUhhbmRsZWRSZXNwb25zZSB7XG4gIGhlYWRlcnM6IElHZW5lcmljT2JqZWN0O1xuICBzdGF0dXM6IG51bWJlcjtcbiAgYm9keTogYW55OyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIGhhbmRsZVJlc3BvbnNlKGJvZHk6IGFueSwgc3RhdHVzID0gSFRUUF9TVEFUVVNfQ09ERS5HRVQpOiBJSGFuZGxlZFJlc3BvbnNlIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICByZXR1cm4ge1xuICAgIGhlYWRlcnM6IGRlZmF1bHRIZWFkZXIsXG4gICAgc3RhdHVzLFxuICAgIGJvZHksXG4gIH07XG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJzaWRlbGFiLWh0dHAtZXhjZXB0aW9uc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJ0c2xpYlwiKTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiaW1wb3J0IHsgQXp1cmVGdW5jdGlvbiwgQ29udGV4dCB9IGZyb20gJ0BhenVyZS9mdW5jdGlvbnMnO1xuaW1wb3J0IHsgaGFuZGxlRXJyb3IsIEhUVFBfU1RBVFVTX0NPREUgfSBmcm9tICdzaWRlbGFiLWh0dHAtZXhjZXB0aW9ucyc7XG5pbXBvcnQgeyBJR2VuZXJpY09iamVjdCB9IGZyb20gJy4uLy4uLy4uL2ludGVyZmFjZXMvZ2VuZXJpYy1vYmplY3QnO1xuaW1wb3J0IGhhbmRsZVJlc3BvbnNlIGZyb20gJy4uLy4uL3V0aWxzL2hhbmRsZS1yZXNwb25zZSc7XG5cbmNvbnN0IGhhbmRsZXI6IEF6dXJlRnVuY3Rpb24gPSBhc3luYyAoY29udGV4dDogQ29udGV4dCwgZXZlbnRIdWJNZXNzYWdlczogSUdlbmVyaWNPYmplY3QpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgY29uc3QgeyBpZCB9ID0gZXZlbnRIdWJNZXNzYWdlcztcbiAgdHJ5IHtcbiAgICBjb25zdCByZXNwb25zZSA9IHsgaWQgfTtcbiAgICBjb250ZXh0LnJlcyA9IGhhbmRsZVJlc3BvbnNlKHJlc3BvbnNlLCBIVFRQX1NUQVRVU19DT0RFLkFDQ0VQVEVEKTtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb250ZXh0LnJlcyA9IGhhbmRsZUVycm9yKGVycm9yLCBjb250ZXh0KTtcbiAgfVxufTtcblxuLy8gdHMtcHJ1bmUtaWdub3JlLW5leHRcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXI7XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=